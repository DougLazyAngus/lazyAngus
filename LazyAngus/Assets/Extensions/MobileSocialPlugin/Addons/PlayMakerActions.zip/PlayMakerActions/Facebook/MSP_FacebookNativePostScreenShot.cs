using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FacebookNativePostScreenShot : FsmStateAction {
		
		public FsmString message;
		public FsmTexture texture;

		
		public override void OnEnter() {

			FacebookPostScreenshotTask post = 	FacebookPostScreenshotTask.Create();
			post.ActionComplete += OnComplete;
			post.Post(message.Value);
			
			
		}
		
		private void OnComplete() {

			Finish();
		}


		
	}
}



