﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FB_Analitycs_ViewedContent : FsmStateAction {

		public FsmFloat  price;
		public FsmString contentType;
		public FsmString contentId;
		public FsmString currency;

		public override void OnEnter() {
			SPFacebookAnalytics.ViewedContent(price.Value, contentType.Value, contentId.Value, currency.Value);
			Finish ();
		}	

		public override void Reset() {
			base.Reset();
			currency.Value =  "USD";
		}
	}
}
