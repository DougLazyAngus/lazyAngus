using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSP_TwitterNativePostScreenshot : FsmStateAction {

		public FsmString message;


		public override void OnEnter() {

			TwitterPostScreenshotTask post = TwitterPostScreenshotTask.Create();
			post.ActionComplete += OnComplete;
			post.Post(message.Value);
		}

		private void OnComplete() {
			Finish();
		}




	}
}


